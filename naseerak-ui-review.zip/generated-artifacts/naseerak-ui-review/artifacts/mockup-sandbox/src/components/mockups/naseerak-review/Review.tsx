import { useMemo, useState, type ReactNode } from "react";
import "./_group.css";

type Page = "home" | "detail" | "team";
type TeamTab = "overview" | "manage" | "drafts" | "profile" | "team";
type Status =
  | "NEW"
  | "IN_PROGRESS"
  | "WAITING_INFORMATION"
  | "REFERRED_TO_AUTHORITY"
  | "IN_CUSTODY"
  | "FOLLOW_UP"
  | "RESOLVED"
  | "CLOSED_NO_FURTHER_ACTION"
  | "WITHDRAWN";
type SourceType = "RESEARCHER" | "VICTIM" | "AUTHORITY" | "OFFICIAL_POST" | "OTHER";
type Verification = "PRELIMINARY" | "UNDER_VERIFICATION" | "VERIFIED_SOURCE" | "OFFICIAL_STATEMENT";
type UpdateKind = "INITIAL" | "UPDATE" | "CORRECTION" | "RESPONSE" | "WITHDRAWAL_NOTICE";

type TimelineUpdate = {
  id: string;
  date: string;
  sourceType: SourceType;
  sourceName: string;
  verification: Verification;
  kind: UpdateKind;
  text: string;
  sourceNote: string;
  limits: string;
  correction?: string;
};

type CaseRecord = {
  number: string;
  title: string;
  summary: string;
  region: string;
  status: Status;
  openedAt: string;
  updates: TimelineUpdate[];
};

const statusLabels: Record<Status, string> = {
  NEW: "معلومات أولية",
  IN_PROGRESS: "قيد المتابعة",
  WAITING_INFORMATION: "معلقة / بانتظار معلومات",
  REFERRED_TO_AUTHORITY: "لدى الأمن / الجهة المختصة",
  IN_CUSTODY: "في قبضة الأمن",
  FOLLOW_UP: "قيد المتابعة",
  RESOLVED: "تم الحل",
  CLOSED_NO_FURTHER_ACTION: "مغلقة دون إجراء إضافي",
  WITHDRAWN: "مسحوبة",
};

const sourceLabels: Record<SourceType, string> = {
  RESEARCHER: "الباحث",
  VICTIM: "صاحب البلاغ",
  AUTHORITY: "جهة مختصة",
  OFFICIAL_POST: "منشور رسمي",
  OTHER: "مصدر آخر",
};

const verificationLabels: Record<Verification, string> = {
  PRELIMINARY: "معلومة أولية",
  UNDER_VERIFICATION: "جارٍ التحقق",
  VERIFIED_SOURCE: "موثقة من مصدر",
  OFFICIAL_STATEMENT: "بيان رسمي",
};

const kindLabels: Record<UpdateKind, string> = {
  INITIAL: "المنشور الأول",
  UPDATE: "تحديث",
  CORRECTION: "تصحيح",
  RESPONSE: "رد/توضيح",
  WITHDRAWAL_NOTICE: "إشعار سحب",
};

const cases: CaseRecord[] = [
  {
    number: "2407",
    title: "بلاغ تجريبي بشأن رسائل تهديد عبر منصة اجتماعية",
    summary: "سجل توضيحي لمتابعة بلاغ، مع إظهار ما ورد في المصدر دون نشر أسماء أو تفاصيل شخصية.",
    region: "تعز",
    status: "IN_PROGRESS",
    openedAt: "١٨ أكتوبر ٢٠٢٦",
    updates: [
      {
        id: "2407-a",
        date: "١٨ أكتوبر ٢٠٢٦ · ١٠:١٥ ص",
        sourceType: "RESEARCHER",
        sourceName: "ملخص متابعة تجريبي",
        verification: "PRELIMINARY",
        kind: "INITIAL",
        text: "ورد بلاغ تجريبي عن رسائل تهديد عبر منصة اجتماعية. أُنشئ هذا السجل لعرض طريقة تنظيم المتابعة، ولا يتضمن أي هوية أو محتوى رسالة.",
        sourceNote: "إفادة أولية ضمن سجل توضيحي داخلي — لا رابط أو مرفقات.",
        limits: "لم تُراجع الرسائل الأصلية، ولا يثبت هذا السجل وقوع مخالفة أو هوية أي طرف.",
      },
      {
        id: "2407-b",
        date: "١٩ أكتوبر ٢٠٢٦ · ٠٢:٤٠ م",
        sourceType: "AUTHORITY",
        sourceName: "إحالة افتراضية في بيانات العرض",
        verification: "UNDER_VERIFICATION",
        kind: "UPDATE",
        text: "يشير التحديث التجريبي إلى إحالة الموضوع للمتابعة لدى الجهة المختصة. لا توجد نتيجة نهائية في هذا المثال.",
        sourceNote: "وصف مصدر مُنشأ للعرض — لا يمثل جهة أو مستندًا حقيقيًا.",
        limits: "الإحالة لا تعني ثبوت ادعاء، ولا يمكن استنتاج نتيجة الإجراء منها.",
      },
      {
        id: "2407-c",
        date: "٢٠ أكتوبر ٢٠٢٦ · ٠٩:٢٠ ص",
        sourceType: "RESEARCHER",
        sourceName: "ملخص متابعة تجريبي",
        verification: "VERIFIED_SOURCE",
        kind: "UPDATE",
        text: "لا يتوفر في المثال ما يضيف واقعة مؤكدة جديدة. سيظل السجل مختصرًا إلى حين ورود مصدر يمكن مراجعته.",
        sourceNote: "مراجعة شكلية لمصدر اصطناعي داخل هذه المعاينة.",
        limits: "درجة التحقق تصف المصدر المتاح فقط، ولا تؤكد الرواية كاملة.",
      },
    ],
  },
  {
    number: "2412",
    title: "متابعة تجريبية لبلاغ ابتزاز رقمي",
    summary: "مثال اصطناعي يوضح فصل الإفادة الأولية عن تحديث جهة مختصة ودرجة التحقق.",
    region: "إب",
    status: "REFERRED_TO_AUTHORITY",
    openedAt: "١٦ أكتوبر ٢٠٢٦",
    updates: [
      {
        id: "2412-a",
        date: "١٦ أكتوبر ٢٠٢٦ · ٠٨:٥٥ ص",
        sourceType: "VICTIM",
        sourceName: "إفادة افتراضية مجهولة",
        verification: "PRELIMINARY",
        kind: "INITIAL",
        text: "إفادة تجريبية حول محاولة ابتزاز رقمي. لا يتضمن المثال أسماء أو محادثات أو ملفات أو بيانات تواصل.",
        sourceNote: "إفادة اصطناعية صيغت للمعاينة فقط.",
        limits: "لم تُفحص أي أدلة رقمية؛ لا يمكن الجزم بصحة الادعاء.",
      },
      {
        id: "2412-b",
        date: "١٧ أكتوبر ٢٠٢٦ · ٠١:١٠ م",
        sourceType: "AUTHORITY",
        sourceName: "وصف إحالة اصطناعي",
        verification: "UNDER_VERIFICATION",
        kind: "UPDATE",
        text: "يظهر هنا تحديث افتراضي عن إحالة البلاغ للمتابعة. تظل التفاصيل محجوبة احترامًا للخصوصية.",
        sourceNote: "سجل إحالة مُختلق لتوضيح حقل المصدر.",
        limits: "لا توجد وثيقة رسمية أو نتيجة نهائية في بيانات العرض.",
      },
    ],
  },
  {
    number: "2386",
    title: "معلومة أولية قيد المراجعة — مثال توضيحي",
    summary: "يُعرض هذا السجل لشرح حالة انتظار المعلومات، لا بوصفه بلاغًا واقعيًا.",
    region: "الحديدة",
    status: "WAITING_INFORMATION",
    openedAt: "١٢ أكتوبر ٢٠٢٦",
    updates: [
      {
        id: "2386-a",
        date: "١٢ أكتوبر ٢٠٢٦ · ١١:٠٥ ص",
        sourceType: "OTHER",
        sourceName: "ملاحظة تجريبية",
        verification: "PRELIMINARY",
        kind: "INITIAL",
        text: "معلومة افتراضية لا تحتوي على وصف شخصي. الحالة معلقة لعدم كفاية المعلومات ضمن هذا السيناريو التجريبي.",
        sourceNote: "ملاحظة مكتوبة خصيصًا للمعاينة.",
        limits: "لا يمكن التحقق من معلومة لم تُرفق معها مصادر قابلة للمراجعة.",
      },
      {
        id: "2386-b",
        date: "١٤ أكتوبر ٢٠٢٦ · ٠٤:٣٠ م",
        sourceType: "RESEARCHER",
        sourceName: "مراجعة افتراضية",
        verification: "UNDER_VERIFICATION",
        kind: "UPDATE",
        text: "لا تغيير في الحالة؛ بانتظار تفاصيل يمكن التحقق منها قبل إضافة أي استنتاج.",
        sourceNote: "تحديث توضيحي من مجموعة البيانات الاصطناعية.",
        limits: "الانتظار لا يعني رفض البلاغ أو ثبوت روايته.",
      },
    ],
  },
  {
    number: "2369",
    title: "قضية تجريبية أُغلق سجلها بعد الحل",
    summary: "مثال لحالة تم الحل، مع توضيح أن نشر التحديث لا يكشف تفاصيل الأطراف.",
    region: "عدن",
    status: "RESOLVED",
    openedAt: "٠٥ أكتوبر ٢٠٢٦",
    updates: [
      {
        id: "2369-a",
        date: "٠٥ أكتوبر ٢٠٢٦ · ٠٩:٠٠ ص",
        sourceType: "RESEARCHER",
        sourceName: "ملخص متابعة تجريبي",
        verification: "PRELIMINARY",
        kind: "INITIAL",
        text: "افتتاح سجل اصطناعي لبلاغ توضيحي، دون تفاصيل قابلة للتعريف.",
        sourceNote: "نص افتراضي — لا توجد وثائق أو أشخاص حقيقيون.",
        limits: "المعلومة الأولية لا تثبت الواقعة.",
      },
      {
        id: "2369-b",
        date: "٠٨ أكتوبر ٢٠٢٦ · ٠٢:١٥ م",
        sourceType: "OFFICIAL_POST",
        sourceName: "وصف بيان افتراضي",
        verification: "OFFICIAL_STATEMENT",
        kind: "UPDATE",
        text: "في هذا السيناريو التجريبي، اكتملت المعالجة وأُغلق السجل. لا تُعرض تفاصيل إضافية حفاظًا على الخصوصية.",
        sourceNote: "إشارة إلى بيان اصطناعي أُنشئ لأغراض تصميم الواجهة.",
        limits: "الحالة المعروضة جزء من بيانات العرض وليست تقريرًا عن واقعة.",
      },
    ],
  },
  {
    number: "2421",
    title: "بلاغ توضيحي جديد — لا توجد تفاصيل منشورة",
    summary: "مثال لحالة معلومات أولية، يبرز ضرورة انتظار مصدر يمكن مراجعته.",
    region: "مأرب",
    status: "NEW",
    openedAt: "٢١ أكتوبر ٢٠٢٦",
    updates: [
      {
        id: "2421-a",
        date: "٢١ أكتوبر ٢٠٢٦ · ٠٨:٣٥ ص",
        sourceType: "OTHER",
        sourceName: "مدخل توضيحي",
        verification: "PRELIMINARY",
        kind: "INITIAL",
        text: "سجل تجريبي جديد؛ لا تُنشر تفاصيل إضافية إلى حين مراجعة المصدر وسلامة مشاركة المعلومات.",
        sourceNote: "عنصر مُنشأ بالكامل لعرض المعاينة.",
        limits: "لا يثبت وجود قضية حقيقية أو صحة أي ادعاء.",
      },
    ],
  },
];

const quickFilters: { label: string; hint: string; icon: IconName; tone: string; status: Status | "ALL" }[] = [
  { label: "القضايا المنشورة", hint: "تصفح آخر القضايا العامة", icon: "list", tone: "mint", status: "ALL" },
  { label: "قضايا قيد المتابعة", hint: "الوصول السريع للقضايا النشطة", icon: "clock", tone: "blue", status: "IN_PROGRESS" },
  { label: "قضايا بيد الجهات المختصة", hint: "متابعة الإحالات", icon: "shield", tone: "gold", status: "REFERRED_TO_AUTHORITY" },
  { label: "تم حل القضية", hint: "عرض القضايا التي انتهت بحل", icon: "check", tone: "mint", status: "RESOLVED" },
];

type IconName =
  | "shield"
  | "moon"
  | "sun"
  | "search"
  | "arrow"
  | "list"
  | "clock"
  | "check"
  | "info"
  | "chevron"
  | "back"
  | "grid"
  | "folder"
  | "users"
  | "person"
  | "file"
  | "lock"
  | "plus"
  | "edit"
  | "send"
  | "trash"
  | "save"
  | "download";

function Icon({ name, size = 16 }: { name: IconName; size?: number }) {
  const shared = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true as const,
  };
  const paths: Record<IconName, ReactNode> = {
    shield: <><path d="M12 3 20 6v5.2c0 4.5-3.1 8.3-8 9.8-4.9-1.5-8-5.3-8-9.8V6l8-3Z" /><path d="m8.5 12 2.2 2.2 4.8-5" /></>,
    moon: <path d="M20.1 15.8A8.7 8.7 0 0 1 8.2 3.9 8.8 8.8 0 1 0 20.1 15.8Z" />,
    sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>,
    search: <><circle cx="10.8" cy="10.8" r="6.8" /><path d="m16 16 4.4 4.4" /></>,
    arrow: <><path d="M19 12H5" /><path d="m11 18-6-6 6-6" /></>,
    list: <><path d="M8 6h12M8 12h12M8 18h12" /><path d="M4 6h.01M4 12h.01M4 18h.01" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    check: <><circle cx="12" cy="12" r="9" /><path d="m8 12 2.5 2.5L16.5 9" /></>,
    info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v5m0-8h.01" /></>,
    chevron: <path d="m7 10 5 5 5-5" />,
    back: <><path d="M19 12H5" /><path d="m11 18-6-6 6-6" /></>,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
    folder: <><path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z" /><path d="M3 10h18" /></>,
    users: <><circle cx="9" cy="8" r="3" /><path d="M3 20c.4-3.2 2.4-5 6-5s5.6 1.8 6 5M16 5.5a3 3 0 0 1 0 5.8M17 15c2.3.3 3.6 1.6 4 4" /></>,
    person: <><circle cx="12" cy="8" r="3.5" /><path d="M5 20c.7-3.1 3.2-5 7-5s6.3 1.9 7 5" /></>,
    file: <><path d="M6 3h8l5 5v13H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z" /><path d="M14 3v5h5M8 13h8m-8 4h8" /></>,
    lock: <><rect x="4" y="10" width="16" height="11" rx="2" /><path d="M8 10V7a4 4 0 1 1 8 0v3m-4 4v3" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    edit: <><path d="m14 5 5 5M4 20l4.5-1 10.6-10.6a2.1 2.1 0 0 0-3-3L5.5 16 4 20Z" /></>,
    send: <><path d="m21 3-7.2 18-3.7-7.1L3 10.2 21 3Z" /><path d="M10.1 13.9 21 3" /></>,
    trash: <><path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3" /></>,
    save: <><path d="M5 3h12l3 3v15H4V4a1 1 0 0 1 1-1Z" /><path d="M8 3v6h8V3m-8 18v-8h8v8" /></>,
    download: <><path d="M12 3v12m-5-5 5 5 5-5" /><path d="M5 18v3h14v-3" /></>,
  };
  return <svg {...shared}>{paths[name]}</svg>;
}

function StatusBadge({ status }: { status: Status }) {
  return <span className="nr-status" data-status={status}>{statusLabels[status]}</span>;
}

function VerificationBadge({ level }: { level: Verification }) {
  return <span className="nr-verification" data-level={level}>{verificationLabels[level]}</span>;
}

function DisabledAction({ icon, children }: { icon: IconName; children: ReactNode }) {
  return (
    <button className="nr-btn nr-btn-disabled" type="button" disabled title="معطل في المعاينة فقط">
      <Icon name={icon} size={14} />
      {children}
    </button>
  );
}

export function Review() {
  const [page, setPage] = useState<Page>("home");
  const [selectedNumber, setSelectedNumber] = useState(cases[0].number);
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<Status | "ALL">("ALL");
  const [selectedTeamTab, setSelectedTeamTab] = useState<TeamTab>("overview");
  const [timelineMode, setTimelineMode] = useState<"all" | "latest">("all");
  const [expandedUpdates, setExpandedUpdates] = useState<Set<string>>(() => new Set(["2407-c"]));

  const selectedCase = cases.find((record) => record.number === selectedNumber) ?? cases[0];

  const filteredCases = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("ar");
    return cases.filter((record) => {
      const matchesStatus = statusFilter === "ALL" || record.status === statusFilter;
      const content = `${record.number} ${record.title} ${record.summary} ${record.region} ${statusLabels[record.status]}`.toLocaleLowerCase("ar");
      return matchesStatus && (!normalized || content.includes(normalized.replace(/^#/, "")));
    });
  }, [query, statusFilter]);

  const navigateToCase = (record: CaseRecord) => {
    setSelectedNumber(record.number);
    setPage("detail");
    setTimelineMode("all");
    setExpandedUpdates(new Set([record.updates[record.updates.length - 1]?.id ?? ""]));
  };

  const chooseQuickFilter = (status: Status | "ALL") => {
    setPage("home");
    setStatusFilter(status);
  };

  const toggleExpanded = (id: string) => {
    setExpandedUpdates((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const visibleUpdates = timelineMode === "latest"
    ? selectedCase.updates.slice(-1)
    : selectedCase.updates;

  return (
    <div className="nr-review-root" data-theme={theme} dir="rtl" lang="ar">
      <div className="nr-demo-ribbon" role="status" aria-live="polite">
        <Icon name="info" size={14} />
        <span>عرض توضيحي · بيانات اصطناعية · لا اتصال ولا كتابة</span>
      </div>

      <header className="nr-header">
        <div className="nr-header-inner">
          <button className="nr-brand" type="button" onClick={() => setPage("home")} aria-label="العودة إلى الرئيسية">
            <span className="nr-brand-mark"><Icon name="shield" size={23} /></span>
            <span>
              <span className="nr-brand-title">نصيرك <span className="nr-brand-latin">Naseerak</span></span>
              <span className="nr-brand-subtitle">متابعة مستجدات قضايا الابتزاز</span>
            </span>
          </button>
          <div className="nr-header-actions">
            <button
              className="nr-btn nr-btn-dark"
              type="button"
              onClick={() => {
                setPage("team");
                setSelectedTeamTab("overview");
              }}
              aria-label="فتح معاينة مساحة الفريق"
            >
              <Icon name="users" size={15} />
              <span>مساحة الفريق</span>
            </button>
            <button
              className="nr-btn nr-btn-dark"
              type="button"
              onClick={() => setTheme((current) => current === "light" ? "dark" : "light")}
              aria-label={theme === "light" ? "تبديل إلى الوضع الليلي" : "تبديل إلى الوضع النهاري"}
              aria-pressed={theme === "dark"}
            >
              <Icon name={theme === "light" ? "moon" : "sun"} size={15} />
              <span>{theme === "light" ? "الوضع الليلي" : "الوضع النهاري"}</span>
            </button>
          </div>
        </div>
      </header>

      <main className="nr-page" id="main-content">
        {page === "home" && (
          <HomePage
            query={query}
            onQueryChange={setQuery}
            statusFilter={statusFilter}
            onStatusFilter={setStatusFilter}
            filteredCases={filteredCases}
            onChooseFilter={chooseQuickFilter}
            onOpenCase={navigateToCase}
          />
        )}
        {page === "detail" && (
          <DetailPage
            record={selectedCase}
            updates={visibleUpdates}
            mode={timelineMode}
            expandedUpdates={expandedUpdates}
            onBack={() => setPage("home")}
            onModeChange={setTimelineMode}
            onToggleExpanded={toggleExpanded}
          />
        )}
        {page === "team" && (
          <TeamPage
            currentTab={selectedTeamTab}
            onSelectTab={setSelectedTeamTab}
            onOpenCase={navigateToCase}
          />
        )}
      </main>

      <footer className="nr-footer">
        <div className="nr-footer-inner">
          <div className="nr-footer-brand">
            <span className="nr-footer-brand-mark"><Icon name="shield" size={18} /></span>
            <span><strong>نصيرك | Naseerak</strong><small>متابعة منظمة للمستجدات ومصادرها</small></span>
          </div>
          <p className="nr-footer-disclaimer">
            إخلاء مسؤولية: تعرض المنصة المستجدات كما ترد من مصادرها، ولا يعني نشر أي قضية تبنّي روايتها أو تأكيد صحتها من المنصة.
          </p>
          <div className="nr-footer-bottom">هذه معاينة محلية فقط — لا تُرسل بيانات ولا تحفظ أي تغيير.</div>
        </div>
      </footer>
    </div>
  );
}

function HomePage({
  query,
  onQueryChange,
  statusFilter,
  onStatusFilter,
  filteredCases,
  onChooseFilter,
  onOpenCase,
}: {
  query: string;
  onQueryChange: (value: string) => void;
  statusFilter: Status | "ALL";
  onStatusFilter: (value: Status | "ALL") => void;
  filteredCases: CaseRecord[];
  onChooseFilter: (value: Status | "ALL") => void;
  onOpenCase: (record: CaseRecord) => void;
}) {
  return (
    <>
      <section className="nr-home-hero" aria-labelledby="nr-home-heading">
        <div className="nr-hero-copy">
          <span className="nr-eyebrow"><Icon name="shield" size={13} /> لوحة متابعة القضايا</span>
          <h1 id="nr-home-heading">كل مستجدات القضية في مكان واحد</h1>
          <p>ابحث برقم القضية أو اسمها أو المنطقة أو حالة المتابعة من خانة واحدة. نعرض مصدر كل تحديث ودرجة التحقق بوضوح.</p>
          <form className="nr-search-form" onSubmit={(event) => event.preventDefault()} role="search" aria-label="البحث في القضايا العامة">
            <label className="nr-search-wrap">
              <span className="nr-visually-hidden">البحث برقم القضية أو الاسم أو الحالة</span>
              <Icon name="search" size={18} />
              <input
                className="nr-search-input"
                type="search"
                value={query}
                onChange={(event) => onQueryChange(event.currentTarget.value)}
                placeholder="رقم القضية، الاسم، المنطقة، أو الحالة…"
                autoComplete="off"
                aria-label="البحث برقم القضية أو الاسم أو الحالة"
              />
            </label>
            <button className="nr-btn nr-btn-primary" type="submit"><Icon name="search" size={15} /> بحث</button>
          </form>
          <div className="nr-hero-note">
            <Icon name="info" size={14} />
            <span>البيانات المعروضة مُنشأة لأغراض التصميم فقط. لا توجد أسماء أشخاص أو بلاغات أو مصادر حقيقية.</span>
          </div>
        </div>
        <div className="nr-quick-links" aria-label="أقسام متابعة القضايا">
          {quickFilters.map((item) => (
            <button key={item.label} className="nr-quick-link" type="button" onClick={() => onChooseFilter(item.status)}>
              <span className="nr-quick-icon" data-tone={item.tone}><Icon name={item.icon} size={17} /></span>
              <span className="nr-quick-copy"><strong>{item.label}</strong><small>{item.hint}</small></span>
              <span className="nr-quick-arrow"><Icon name="arrow" size={14} /></span>
            </button>
          ))}
        </div>
      </section>

      <section className="nr-section" aria-labelledby="nr-feed-heading">
        <div className="nr-section-head">
          <h2 className="nr-section-title" id="nr-feed-heading"><span className="nr-section-mark" />أحدث القضايا العامة</h2>
          <span className="nr-section-meta">{filteredCases.length} سجلات تجريبية · مرتبة حسب آخر تحديث</span>
        </div>
        <div className="nr-feed-controls">
          <div className="nr-filter-pills" role="group" aria-label="تصفية سريعة حسب حالة القضية">
            {[
              ["ALL", "الكل"],
              ["IN_PROGRESS", "قيد المتابعة"],
              ["REFERRED_TO_AUTHORITY", "لدى جهة مختصة"],
              ["WAITING_INFORMATION", "بانتظار معلومات"],
              ["RESOLVED", "تم الحل"],
            ].map(([value, label]) => (
              <button
                key={value}
                className="nr-filter-pill"
                type="button"
                aria-pressed={statusFilter === value}
                onClick={() => onStatusFilter(value as Status | "ALL")}
              >
                {label}
              </button>
            ))}
          </div>
          <label>
            <span className="nr-visually-hidden">تصفية حسب حالة المتابعة</span>
            <select
              className="nr-status-select"
              value={statusFilter}
              onChange={(event) => onStatusFilter(event.currentTarget.value as Status | "ALL")}
              aria-label="تصفية حسب حالة المتابعة"
            >
              <option value="ALL">كل حالات المتابعة</option>
              {(Object.entries(statusLabels) as [Status, string][]).map(([status, label]) => (
                <option key={status} value={status}>{label}</option>
              ))}
            </select>
          </label>
        </div>

        {filteredCases.length === 0 ? (
          <div className="nr-empty" role="status">
            <h3>لا توجد نتائج مطابقة</h3>
            <p>جرّب كلمة أو حالة متابعة مختلفة.</p>
          </div>
        ) : (
          <div className="nr-case-grid" role="list" aria-label="القضايا العامة التجريبية">
            {filteredCases.map((record) => (
              <button
                key={record.number}
                className="nr-case-card"
                type="button"
                onClick={() => onOpenCase(record)}
                aria-label={`فتح القضية رقم ${record.number}: ${record.title}`}
              >
                <span className="nr-card-top">
                  <span className="nr-case-number">القضية #{record.number}</span>
                  <StatusBadge status={record.status} />
                </span>
                <span><h3>{record.title}</h3><span className="nr-card-region">المنطقة: {record.region}</span></span>
                <p>{record.summary}</p>
                <span className="nr-card-bottom">
                  <span><strong className="nr-update-count">{record.updates.length}</strong> تحديثات منشورة</span>
                  <span>{record.updates[record.updates.length - 1]?.date.split(" · ")[0]}</span>
                </span>
              </button>
            ))}
          </div>
        )}
      </section>
    </>
  );
}

function DetailPage({
  record,
  updates,
  mode,
  expandedUpdates,
  onBack,
  onModeChange,
  onToggleExpanded,
}: {
  record: CaseRecord;
  updates: TimelineUpdate[];
  mode: "all" | "latest";
  expandedUpdates: Set<string>;
  onBack: () => void;
  onModeChange: (mode: "all" | "latest") => void;
  onToggleExpanded: (id: string) => void;
}) {
  const latest = record.updates[record.updates.length - 1];
  return (
    <>
      <div className="nr-detail-toolbar">
        <button className="nr-btn" type="button" onClick={onBack}><Icon name="back" size={15} /> العودة للبحث</button>
        <span className="nr-readonly-label"><Icon name="lock" size={13} /> سجل عام · معاينة فقط</span>
      </div>
      <section className="nr-detail-top" aria-labelledby="nr-case-title">
        <div className="nr-status-panel">
          <div className="nr-detail-grid">
            <div>
              <div className="nr-detail-meta">
                <span className="nr-case-number">القضية #{record.number}</span>
                <StatusBadge status={record.status} />
                <span className="nr-detail-date">تاريخ الفتح: {record.openedAt}</span>
                <span className="nr-verification">المنطقة: {record.region}</span>
              </div>
              <h1 id="nr-case-title">{record.title}</h1>
              <p>{record.summary}</p>
            </div>
            <aside className="nr-latest-box" aria-label="آخر مستجد مباشر">
              <small>آخر مستجد مباشر</small>
              <strong>{latest?.text ?? "لا توجد تحديثات منشورة بعد."}</strong>
              <span>{latest ? `تاريخ التحديث: ${latest.date}` : "—"}</span>
            </aside>
          </div>
        </div>
        <div className="nr-caution">
          <Icon name="info" size={15} />
          <span><strong>تنبيه بشأن التحقق:</strong> تعرض المنصة المستجدات كما ترد من مصادرها. النشر لا يعني تبنّي الرواية أو تأكيد صحتها، ودرجة التحقق تخص المصدر المتاح فقط.</span>
        </div>
      </section>

      <section className="nr-surface" aria-labelledby="nr-timeline-heading">
        <div className="nr-section-head">
          <div>
            <h2 className="nr-section-title" id="nr-timeline-heading"><span className="nr-section-mark" />السجل الزمني للتحديثات</h2>
            <span className="nr-section-meta">{record.updates.length} تحديثات منشورة · مصدر كل تحديث ظاهر أدناه</span>
          </div>
          <div className="nr-timeline-controls" role="group" aria-label="طريقة عرض التحديثات">
            <button className="nr-view-btn" type="button" aria-pressed={mode === "all"} onClick={() => onModeChange("all")}>عرض كل التحديثات</button>
            <button className="nr-view-btn" type="button" aria-pressed={mode === "latest"} onClick={() => onModeChange("latest")}>عرض آخر تحديث فقط</button>
          </div>
        </div>
        <div className="nr-timeline">
          {updates.map((update) => {
            const expanded = expandedUpdates.has(update.id);
            const timelineIndex = record.updates.findIndex((item) => item.id === update.id);
            return (
              <article className="nr-timeline-item" key={update.id}>
                <span className="nr-timeline-index" aria-label={`التحديث ${timelineIndex + 1}`}>{String(timelineIndex + 1).padStart(2, "0")}</span>
                <div className="nr-timeline-card">
                  <div className="nr-timeline-head">
                    <div className="nr-timeline-badges">
                      <span className="nr-source"><Icon name="file" size={11} />{sourceLabels[update.sourceType]}</span>
                      <VerificationBadge level={update.verification} />
                      <span className="nr-kind">{update.kind === "UPDATE" ? `${kindLabels[update.kind]} ${timelineIndex + 1}` : kindLabels[update.kind]}</span>
                    </div>
                    <time className="nr-timeline-date">{update.date}</time>
                  </div>
                  <div className="nr-timeline-summary">
                    <p>{update.text}</p>
                    <button
                      className="nr-expand-btn"
                      type="button"
                      aria-expanded={expanded}
                      aria-label={`${expanded ? "إخفاء" : "عرض"} تفاصيل المصدر للتحديث ${timelineIndex + 1}`}
                      onClick={() => onToggleExpanded(update.id)}
                    >
                      <Icon name="chevron" size={15} />
                    </button>
                  </div>
                  {expanded && (
                    <div className="nr-source-line">
                      <strong>المصدر:</strong> {update.sourceName} — {update.sourceNote}
                      <div className="nr-source-context">
                        <div><small>درجة التحقق</small><strong>{verificationLabels[update.verification]}</strong></div>
                        <div><small>ما الذي يمكن استنتاجه؟</small><strong>{update.limits}</strong></div>
                      </div>
                      {update.correction && <div className="nr-correction-note"><strong>تصحيح شفاف:</strong> {update.correction}</div>}
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
        <p className="nr-detail-footnote">
          {mode === "latest" ? `يعرض هذا الوضع آخر تحديث فقط من أصل ${record.updates.length}.` : `يُعرض الأحدث ضمن السجل مع إبقاء سياق كل مصدر قابلًا للفتح.`}
          {" "}لا تتضمن هذه المعاينة صورًا أو مرفقات أو بيانات شخصية.
        </p>
      </section>
    </>
  );
}

const teamTabs: { id: TeamTab; label: string; icon: IconName }[] = [
  { id: "overview", label: "نظرة عامة", icon: "grid" },
  { id: "manage", label: "إدارة قضية", icon: "folder" },
  { id: "drafts", label: "المسودات", icon: "clock" },
  { id: "profile", label: "ملفي الشخصي", icon: "person" },
  { id: "team", label: "الفريق والصلاحيات", icon: "users" },
];

function TeamPage({
  currentTab,
  onSelectTab,
  onOpenCase,
}: {
  currentTab: TeamTab;
  onSelectTab: (tab: TeamTab) => void;
  onOpenCase: (record: CaseRecord) => void;
}) {
  const [teamSearch, setTeamSearch] = useState("");
  const teamRows = cases.filter((record) =>
    `${record.number} ${record.title} ${statusLabels[record.status]}`.toLocaleLowerCase("ar").includes(teamSearch.toLocaleLowerCase("ar")),
  );
  const visibleTabs = teamTabs.filter((tab) => tab.id !== "profile");

  return (
    <div className="nr-team-layout">
      <aside className="nr-team-sidebar" aria-label="تنقل مساحة الفريق">
        <div className="nr-team-brand">
          <span className="nr-team-brand-mark"><Icon name="shield" size={19} /></span>
          <span><strong>مساحة الفريق</strong><small>نصيرك · متابعة المستجدات</small></span>
        </div>
        <p className="nr-sidebar-label">التنقل</p>
        <nav className="nr-team-nav" aria-label="أقسام لوحة الفريق">
          {visibleTabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              aria-current={currentTab === tab.id ? "page" : undefined}
              onClick={() => onSelectTab(tab.id)}
            >
              <Icon name={tab.icon} size={15} /><span>{tab.label}</span>
            </button>
          ))}
        </nav>
      </aside>

      <div className="nr-team-content">
        <section className="nr-team-hero">
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
              <h1>لوحة متابعة القضايا</h1>
              <span className="nr-readonly-label">معاينة فريق غير مسجلة</span>
            </div>
            <p>راجع المستجدات ومصادرها قبل النشر. هذه مساحة توضيحية للقراءة فقط ولا تتصل بحساب فريق.</p>
          </div>
          <div className="nr-team-actions" aria-label="إجراءات معطلة في المعاينة">
            <DisabledAction icon="plus">إنشاء قضية</DisabledAction>
            <DisabledAction icon="file">إضافة تحديث زمني</DisabledAction>
            <DisabledAction icon="download">تصدير</DisabledAction>
          </div>
        </section>
        <p className="nr-preview-explain">
          <strong>للمعاينة فقط:</strong> إنشاء، تحرير، نشر، حذف، حفظ وتصدير معطّل. لا توجد مصادقة، ولا تُحفظ أي تغييرات. البيانات اصطناعية بالكامل.
        </p>

        <div className="nr-team-tabs" role="tablist" aria-label="أقسام لوحة الفريق">
          {visibleTabs.map((tab) => (
            <button
              key={tab.id}
              className="nr-team-tab"
              type="button"
              role="tab"
              aria-selected={currentTab === tab.id}
              aria-pressed={currentTab === tab.id}
              onClick={() => onSelectTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {currentTab === "overview" && (
          <TeamOverview
            rows={teamRows}
            search={teamSearch}
            onSearch={setTeamSearch}
            onOpenCase={onOpenCase}
          />
        )}
        {currentTab === "manage" && (
          <section className="nr-team-panel">
            <div className="nr-panel-heading">
              <div><h2>إدارة قضية</h2><p>سجلات عامة للمعاينة — الإجراءات غير متاحة.</p></div>
              <DisabledAction icon="edit">تحرير</DisabledAction>
            </div>
            <div className="nr-table-wrap"><TeamTable rows={teamRows} onOpenCase={onOpenCase} /></div>
          </section>
        )}
        {currentTab === "drafts" && (
          <section className="nr-team-panel">
            <div className="nr-panel-heading">
              <div><h2>المسودات</h2><p>لا توجد مسودات حقيقية في هذه المعاينة.</p></div>
              <span className="nr-readonly-label">بيانات اصطناعية</span>
            </div>
            <div className="nr-empty">
              <h3>لا توجد مسودات محفوظة</h3>
              <p>المعاينة للقراءة فقط؛ لن تُنشأ أو تُحفظ أي مسودة.</p>
            </div>
            <div className="nr-team-actions" style={{ marginTop: 12 }}>
              <DisabledAction icon="save">حفظ مسودة</DisabledAction>
              <DisabledAction icon="send">نشر</DisabledAction>
              <DisabledAction icon="trash">حذف</DisabledAction>
            </div>
          </section>
        )}
        {currentTab === "team" && (
          <section className="nr-team-panel">
            <div className="nr-panel-heading">
              <div><h2>الفريق والصلاحيات</h2><p>لا توجد حسابات أعضاء أو صلاحيات فعلية ضمن المعاينة.</p></div>
              <DisabledAction icon="plus">إضافة عضو</DisabledAction>
            </div>
            <div className="nr-empty">
              <h3>معاينة غير مسجلة</h3>
              <p>الصلاحيات الفعلية تُطبّق من قاعدة البيانات في المنتج؛ هذه الصفحة لا تسجل دخولًا ولا تغيّر أي صلاحيات.</p>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function TeamOverview({
  rows,
  search,
  onSearch,
  onOpenCase,
}: {
  rows: CaseRecord[];
  search: string;
  onSearch: (value: string) => void;
  onOpenCase: (record: CaseRecord) => void;
}) {
  return (
    <>
      <div className="nr-stats" aria-label="ملخص أرقام تجريبية">
        <div className="nr-stat"><strong>٠٥</strong><span>قضايا عامة تجريبية</span><small>بيانات عرض فقط</small></div>
        <div className="nr-stat"><strong>٠٢</strong><span>قيد المتابعة</span><small>حالة اصطناعية</small></div>
        <div className="nr-stat"><strong>٠١</strong><span>بيد جهة مختصة</span><small>لا يشير إلى جهة حقيقية</small></div>
        <div className="nr-stat"><strong>٠١</strong><span>تم الحل</span><small>مثال للحالة النهائية</small></div>
      </div>

      <section className="nr-team-panel">
        <div className="nr-panel-heading">
          <div><h2>القضايا المنشورة</h2><p>راجع الحالة والمصدر قبل النشر في النظام الفعلي.</p></div>
          <DisabledAction icon="download">تصدير</DisabledAction>
        </div>
        <div className="nr-feed-controls">
          <label className="nr-search-wrap" style={{ flex: "1 1 220px" }}>
            <span className="nr-visually-hidden">بحث في سجلات الفريق</span>
            <Icon name="search" size={15} />
            <input
              className="nr-status-select"
              type="search"
              value={search}
              onChange={(event) => onSearch(event.currentTarget.value)}
              placeholder="ابحث برقم القضية أو الحالة…"
              aria-label="بحث في سجلات الفريق"
            />
          </label>
          <span className="nr-readonly-label"><Icon name="lock" size={12} /> عرض تجريبي للقراءة فقط</span>
        </div>
        <div className="nr-table-wrap">
          <TeamTable rows={rows} onOpenCase={onOpenCase} />
        </div>
        <p className="nr-disabled-note">اختيار سجل يفتح تفاصيله العامة. أزرار التحرير والنشر والحذف غير متاحة في هذا النموذج.</p>
      </section>

      <div className="nr-team-subgrid">
        <section className="nr-team-panel">
          <div className="nr-panel-heading"><div><h2>آخر النشاط</h2><p>أمثلة اصطناعية لسجل المراجعة</p></div></div>
          <div className="nr-activity-list">
            <div className="nr-activity-row"><span className="nr-activity-dot" /><p>مراجعة مصدر تحديث للقضية #2407<small>اليوم · ٠٩:٢٠ ص · بيانات تجريبية</small></p></div>
            <div className="nr-activity-row"><span className="nr-activity-dot" /><p>تغيير حالة سجل إلى «لدى الأمن / الجهة المختصة»<small>أمس · ٠١:١٠ م · بيانات تجريبية</small></p></div>
            <div className="nr-activity-row"><span className="nr-activity-dot" /><p>إضافة توضيح لدرجة التحقق<small>١٩ أكتوبر · ٠٢:٤٠ م · بيانات تجريبية</small></p></div>
          </div>
        </section>
        <section className="nr-team-panel">
          <div className="nr-panel-heading"><div><h2>مصادر التحديث</h2><p>حقول عرض مصدر المعلومة</p></div></div>
          <div className="nr-source-list">
            <div className="nr-source-list-item"><strong>الباحث</strong><span>معلومة أولية</span></div>
            <div className="nr-source-list-item"><strong>جهة مختصة</strong><span>جارٍ التحقق</span></div>
            <div className="nr-source-list-item"><strong>منشور رسمي</strong><span>بيان رسمي</span></div>
          </div>
        </section>
      </div>
    </>
  );
}

function TeamTable({ rows, onOpenCase }: { rows: CaseRecord[]; onOpenCase: (record: CaseRecord) => void }) {
  if (rows.length === 0) {
    return <div className="nr-empty"><h3>لا توجد نتائج مطابقة</h3><p>جرّب رقمًا أو حالة أخرى.</p></div>;
  }
  return (
    <table className="nr-team-table">
      <thead>
        <tr><th scope="col">القضية</th><th scope="col">حالة المتابعة</th><th scope="col">المنطقة</th><th scope="col">المصدر الأخير</th><th scope="col">التحديثات</th><th scope="col">إجراءات</th></tr>
      </thead>
      <tbody>
        {rows.map((record) => {
          const latest = record.updates[record.updates.length - 1];
          return (
            <tr key={record.number}>
              <td>
                <button
                  type="button"
                  className="nr-table-case-title"
                  style={{ padding: 0, border: 0, background: "transparent", textAlign: "right", cursor: "pointer" }}
                  onClick={() => onOpenCase(record)}
                  aria-label={`عرض تفاصيل القضية ${record.number}`}
                >
                  {record.title}
                </button>
                <span className="nr-table-case-sub">#{record.number} · منشور تجريبي</span>
              </td>
              <td><StatusBadge status={record.status} /></td>
              <td>{record.region}</td>
              <td>{latest ? sourceLabels[latest.sourceType] : "—"}</td>
              <td>{record.updates.length}</td>
              <td><DisabledAction icon="edit">تحرير</DisabledAction></td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
